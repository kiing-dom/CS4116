<!DOCTYPE html>
<link rel="stylesheet" href="wavelengthPages.css">

<head>
    <title>Feed</title>

    </head>

<body>
<header>
    <?php
        include('navBar.php');
        ?>
   </header> 

<h1>Your Feed</h1>

</body>

</html>